
import torch
import torchvision
from torch.utils.data import DataLoader
from torchvision import transforms
import numpy as np
from numpy import save
from tqdm import tqdm

# from imagenet_resnet_feature_extraction import Img2Vec
from imagenet_dataset import ImageNetDataset

import sys
import os
import requests

from PIL import Image

# # check whether run in Colab
# if 'google.colab' in sys.modules:
#     print('Running in Colab.')
#     !pip3 install timm==0.4.5  # 0.3.2 does not work in Colab
#     !git clone https://github.com/facebookresearch/mae.git
#     sys.path.append('./mae')
# else:
#     sys.path.append('..')
# sys.path.append('..')
import models_mae


batch_size = 512

# IDEA cluster
root_path = "/home/ngwetl/LILIAN_RESEARCH/data/IMAGENET" # path to folder containing ImageNet class labels 
root_path_dog_sketch = "/home/ngwetl/LILIAN_RESEARCH/data/IMAGENET/stylized_imagenet/dog_sketch" # path to images stylized with dog sketch
root_path_picasso_dog = "/home/ngwetl/LILIAN_RESEARCH/data/IMAGENET/stylized_imagenet/picasso_right" # path to images stylized with Picasso dog
root_path_woman_sketch = "/home/ngwetl/LILIAN_RESEARCH/data/IMAGENET/stylized_imagenet/girl_sketch" # path to images stylized with woman sketch
root_path_picasso_sp= "/home/ngwetl/LILIAN_RESEARCH/data/IMAGENET/stylized_imagenet/picasso_original" # path to images stylized with Picasso self portrait


# #AiMOS
# root_path = "/gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/data/imagenet_kaggle" # path to folder containing ImageNet class labels 
# root_path_dog_sketch = "/gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/data/imagenet_kaggle/stylized_imagenet/dog_sketch" # path to images stylized with dog sketch
# root_path_picasso_dog = "/gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/data/imagenet_kaggle/stylized_imagenet/picasso_right" # path to images stylized with Picasso dog
# root_path_woman_sketch = "/gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/data/imagenet_kaggle/stylized_imagenet/girl_sketch" # path to images stylized with woman sketch
# root_path_picasso_sp= "/gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/data/imagenet_kaggle/stylized_imagenet/picasso_original" # path to images stylized with Picasso self portrait


mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)

train_transform = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(mean, std),
            ]
        )

val_transform = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize(mean, std),
            ]
        )

def create_dataloaders(root_path, root_path_style):
    train_dataset = ImageNetDataset(root_path,root_path_style, "train", train_transform)
    train_dataloader = DataLoader(
                train_dataset,
                batch_size=batch_size, 
                # num_workers=8, 
                shuffle=False,
                drop_last=False,
                pin_memory=True
            )

    val_dataset = ImageNetDataset(root_path, root_path_style, "val/val_images", val_transform)
    val_dataloader = DataLoader(
                val_dataset,
                batch_size=batch_size, 
                # num_workers=0, 
                shuffle=False,
                drop_last=False,
                pin_memory=True
            )
    return train_dataloader, val_dataloader



def prepare_model(chkpt_dir, arch='mae_vit_base_patch16'):
    # build model
    model = getattr(models_mae, arch)()
    # load model
    checkpoint = torch.load(chkpt_dir, map_location='cpu')
    msg = model.load_state_dict(checkpoint['model'], strict=False)
    print(msg)
    return model
    
    

    
# Function to extract image features using MAE    
def get_features(dataloader, model):
    Z_list = []
    labels_list = []
    for images_batch, labels_batch in tqdm(dataloader):
        Z_batch = model(images_batch.float()).detach().numpy()
        Z_list.append(Z_batch)
        labels_list.append(labels_batch.numpy())
    Z = np.vstack(Z_list)
    labels = np.array(labels_list).flatten()
    print("Z features shape", Z.shape)
    return Z, labels




# generate dataloaders for different imagenet styles
dog_sketch_train_dataloader, dog_sketch_val_dataloader = create_dataloaders(root_path, root_path_dog_sketch)
picasso_dog_train_dataloader, picasso_dog_val_dataloader = create_dataloaders(root_path, root_path_picasso_dog)
woman_sketch_train_dataloader, woman_sketch_val_dataloader = create_dataloaders(root_path, root_path_woman_sketch)
picasso_sp_train_dataloader, picasso_sp_val_dataloader = create_dataloaders(root_path, root_path_picasso_sp)


### Load a pre-trained MAE base model
chkpt_dir_base = 'mae_finetuned_vit_base.pth'
model_mae_base = prepare_model(chkpt_dir_base, 'mae_vit_base_patch16')
print('MAE base model loaded.')

### Load a pre-trained MAE large model
chkpt_dir_large = 'mae_finetuned_vit_large.pth'
model_mae_large = prepare_model(chkpt_dir_large, 'mae_vit_large_patch16')
print('MAE large model loaded.')

### Load a pre-trained MAE huge model
chkpt_dir_huge = 'mae_finetuned_vit_huge.pth'
model_mae_huge = prepare_model(chkpt_dir_huge, 'mae_vit_huge_patch14')
print('MAE huge model loaded.')




# Extract image features and save extracted features and image labels as numpy files
print("### Extracting features using pre-trained MAE ###")
Z_train_dog_sketch_mae_base, train_dog_sketch_labels_mae_base = get_features(dog_sketch_train_dataloader, model_mae_base)
save('../data/Z_train_dog_sketch_imagenet_mae_base.npy', Z_train_dog_sketch_mae_base)
save('../data/train_dog_sketch_labels_imagenet_mae_base.npy', train_dog_sketch_labels_mae_base)
# Z_train_dog_sketch_mae_large, train_dog_sketch_labels_mae_large = get_features(dog_sketch_train_dataloader, model_mae_large)
# save('../data/Z_train_dog_sketch_imagenet_mae_large.npy', Z_train_dog_sketch_mae_large)
# save('../data/train_dog_sketch_labels_imagenet_mae_large.npy', train_dog_sketch_labels_mae_large)
# Z_train_dog_sketch_mae_huge, train_dog_sketch_labels_mae_huge = get_features(dog_sketch_train_dataloader, model_mae_huge)
# save('../data/Z_train_dog_sketch_imagenet_mae_large.npy', Z_train_dog_sketch_mae_huge)
# save('../data/train_dog_sketch_labels_imagenet_mae_large.npy', train_dog_sketch_labels_mae_huge)

print("Done extracting dog sketch train features!")

Z_train_picasso_dog_mae_base, train_picasso_dog_labels_mae_base = get_features(picasso_dog_train_dataloader, model_mae_base)
save('../data/Z_train_picasso_dog_imagenet_mae_base.npy', Z_train_picasso_dog_mae_base)
save('../data/train_picasso_dog_labels_imagenet_mae_base.npy', train_picasso_dog_labels_mae_base)
# Z_train_picasso_dog_mae_large, train_picasso_dog_labels_mae_large = get_features(picasso_dog_train_dataloader, model_mae_large)
# save('../data/Z_train_picasso_dog_imagenet_mae_large.npy', Z_train_picasso_dog_mae_large)
# save('../data/train_picasso_dog_labels_imagenet_mae_large.npy', train_picasso_dog_labels_mae_large)
# Z_train_picasso_dog_mae_huge, train_picasso_dog_labels_mae_huge = get_features(picasso_dog_train_dataloader, model_mae_huge)
# save('../data/Z_train_picasso_dog_imagenet_mae_huge.npy', Z_train_picasso_dog_mae_huge)
# save('../data/train_picasso_dog_labels_imagenet_mae_huge.npy', train_picasso_dog_labels_mae_huge)

print("Done extracting Picasso dog train features!")

Z_train_woman_sketch_mae_base, train_woman_sketch_labels_mae_base = get_features(woman_sketch_train_dataloader, model_mae_base)
save('../data/Z_train_woman_sketch_imagenet_mae_base.npy', Z_train_woman_sketch_mae_base)
save('../data/train_woman_sketch_labels_imagenet_mae_base.npy', train_woman_sketch_labels_mae_base)
# Z_train_woman_sketch_mae_large,train_woman_sketch_labels_mae_large = get_features(woman_sketch_train_dataloader,model_mae_large)
# save('../data/Z_train_woman_sketch_imagenet_mae_large.npy', Z_train_woman_sketch_mae_large)
# save('../data/train_woman_sketch_labels_imagenet_mae_large.npy', train_woman_sketch_labels_mae_large)
# Z_train_woman_sketch_mae_huge, train_woman_sketch_labels_mae_huge = get_features(woman_sketch_train_dataloader, model_mae_huge)
# save('../data/Z_train_woman_sketch_imagenet_mae_huge.npy', Z_train_woman_sketch_mae_huge)
# save('../data/train_woman_sketch_labels_imagenet_mae_huge.npy', train_woman_sketch_labels_mae_huge)

print("Done extracting woman sketch train features!")

Z_train_picasso_sp_mae_base, train_picasso_sp_labels_mae_base = get_features(picasso_sp_train_dataloader, model_mae_base)
save('../data/Z_train_picasso_sp_mae_base.npy', Z_train_picasso_sp_mae_base)
save('../data/train_picasso_sp_labels_imagenet_mae_base.npy', train_picasso_sp_labels_mae_base)
# Z_train_picasso_sp_mae_large, train_picasso_sp_labels_mae_large = get_features(picasso_sp_train_dataloader, model_mae_large)
# save('../data/Z_train_picasso_sp_mae_large.npy', Z_train_picasso_sp_mae_large)
# save('../data/train_picasso_sp_labels_imagenet_mae_large.npy', train_picasso_sp_labels_mae_large)
# Z_train_picasso_sp_mae_huge, train_picasso_sp_labels_mae_huge = get_features(picasso_sp_train_dataloader, model_mae_huge)
# save('../data/Z_train_picasso_sp_mae_huge.npy', Z_train_picasso_sp_mae_huge)
# save('../data/train_picasso_sp_labels_imagenet_mae_huge.npy', train_picasso_sp_labels_mae_huge)

print("Done extracting Picasso sp train features!")

Z_test_dog_sketch_mae_base, test_dog_sketch_labels_mae_base = get_features(dog_sketch_val_dataloader, model_mae_base)
save('../data/Z_test_dog_sketch_imagenet_mae_base.npy', Z_test_dog_sketch_mae_base)
save('../data/test_dog_sketch_labels_imagenet_mae_base.npy', test_dog_sketch_labels_mae_base)
# Z_test_dog_sketch_mae_large, test_dog_sketch_labels_mae_large = get_features(dog_sketch_val_dataloader, model_mae_large)
# save('../data/Z_test_dog_sketch_imagenet_mae_large.npy', Z_test_dog_sketch_mae_large)
# save('../data/test_dog_sketch_labels_imagenet_mae_large.npy', test_dog_sketch_labels_mae_large)
# Z_test_dog_sketch_mae_huge, test_dog_sketch_labels_mae_huge = get_features(dog_sketch_val_dataloader, model_mae_huge)
# save('../data/Z_test_dog_sketch_imagenet_mae_huge.npy', Z_test_dog_sketch_mae_huge)
# save('../data/test_dog_sketch_labels_imagenet_mae_huge.npy', test_dog_sketch_labels_mae_huge)

print("Done extracting dog sketch test features!")

Z_test_picasso_dog_mae_base, test_picasso_dog_labels_mae_base = get_features(picasso_dog_val_dataloader, model_mae_base)
save('../data/Z_test_picasso_dog_imagenet_mae_base.npy', Z_test_picasso_dog_mae_base)
save('../data/test_picasso_dog_labels_imagenet_mae_base.npy', test_picasso_dog_labels_mae_base)
# Z_test_picasso_dog_mae_large, test_picasso_dog_labels_mae_large = get_features(picasso_dog_val_dataloader, model_mae_large)
# save('../data/Z_test_picasso_dog_imagenet_mae_large.npy', Z_test_picasso_dog_mae_large)
# save('../data/test_picasso_dog_labels_imagenet_mae_large.npy', test_picasso_dog_labels_mae_large)
# Z_test_picasso_dog_mae_huge, test_picasso_dog_labels_mae_huge = get_features(picasso_dog_val_dataloader, model_mae_huge)
# save('../data/Z_test_picasso_dog_imagenet_mae_huge.npy', Z_test_picasso_dog_mae_huge)
# save('../data/test_picasso_dog_labels_imagenet_mae_huge.npy', test_picasso_dog_labels_mae_huge)

print("Done extracting Picasso dog test features!")

Z_test_woman_sketch_mae_base, test_woman_sketch_labels_mae_base = get_features(woman_sketch_val_dataloader, model_mae_base)
save('../data/Z_test_woman_sketch_imagenet_mae_base.npy', Z_test_woman_sketch_mae_base)
save('../data/test_woman_sketch_labels_imagenet_mae_base.npy', test_woman_sketch_labels_mae_base)
# Z_test_woman_sketch_mae_large, test_woman_sketch_labels_mae_large = get_features(woman_sketch_val_dataloader, model_mae_large)
# save('../data/Z_test_woman_sketch_imagenet_mae_large.npy', Z_test_woman_sketch_mae_large)
# save('../data/test_woman_sketch_labels_imagenet_mae_large.npy', test_woman_sketch_labels_mae_large)
# Z_test_woman_sketch_mae_huge, test_woman_sketch_labels_mae_huge = get_features(woman_sketch_val_dataloader, model_mae_huge)
# save('../data/Z_test_woman_sketch_imagenet_mae_huge.npy', Z_test_woman_sketch_mae_huge)
# save('../data/test_woman_sketch_labels_imagenet_mae_huge.npy', test_woman_sketch_labels_mae_huge)

print("Done extracting woman sketch test features!")

Z_test_picasso_sp_mae_base, test_picasso_sp_labels_mae_base = get_features(picasso_sp_val_dataloader, model_mae_base)
save('../data/Z_test_picasso_sp_imagenet_mae_base.npy', Z_test_picasso_sp_mae_base)
save('../data/test_picasso_sp_labels_imagenet_mae_base.npy', test_picasso_sp_labels_mae_base)
# Z_test_picasso_sp_mae_large, test_picasso_sp_labels_mae_large = get_features(picasso_sp_val_dataloader, model_mae_large)
# save('../data/Z_test_picasso_sp_imagenet_mae_large.npy', Z_test_picasso_sp_mae_large)
# save('../data/test_picasso_sp_labels_imagenet_mae_large.npy', test_picasso_sp_labels_mae_large)
# Z_test_picasso_sp_mae_huge, test_picasso_sp_labels_mae_huge = get_features(picasso_sp_val_dataloader, model_mae_huge)
# save('../data/Z_test_picasso_sp_imagenet_mae_huge.npy', Z_test_picasso_sp_mae_large)
# save('../data/test_picasso_sp_labels_imagenet_mae_huge.npy', test_picasso_sp_labels_mae_large)

print("Done extracting Picasso sp test features!")

# # Save extracted features and image labels as numpy files
# save('../data/Z_train_dog_sketch_imagenet_resnet.npy', Z_train_dog_sketch)
# save('../data/Z_train_picasso_dog_imagenet_resnet.npy', Z_train_picasso_dog)
# save('../data/Z_train_woman_sketch_imagenet_resnet.npy', Z_train_woman_sketch)
# save('../data/Z_train_picasso_sp_resnet.npy', Z_train_picasso_sp)


# save('../data/Z_test_dog_sketch_imagenet_resnet.npy', Z_test_dog_sketch)
# save('../data/Z_test_picasso_dog_imagenet_resnet.npy', Z_test_picasso_dog)
# save('../data/Z_test_woman_sketch_imagenet_resnet.npy', Z_test_woman_sketch)
# save('../data/Z_test_picasso_sp_imagenet_resnet.npy', Z_test_picasso_sp)


# save('../data/train_dog_sketch_labels_imagenet.npy', train_dog_sketch_labels)
# save('../data/train_picasso_dog_labels_imagenet.npy', train_picasso_dog_labels)
# save('../data/train_woman_sketch_labels_imagenet.npy', train_woman_sketch_labels)
# save('../data/train_picasso_sp_labels_imagenet.npy', train_picasso_sp_labels)

# save('../data/test_dog_sketch_labels_imagenet.npy', test_dog_sketch_labels)
# save('../data/test_picasso_dog_labels_imagenet.npy', test_picasso_dog_labels)
# save('../data/test_woman_sketch_labels_imagenet.npy', test_woman_sketch_labels)
# save('../data/test_picasso_sp_labels_imagenet.npy', test_picasso_sp_labels)


