#!/bin/bash
#SBATCH --job-name=stylized_imagenet
#SBATCH --output=logs/sty-imagenet_%A_%a.out
#SBATCH --nodes=1
#SBATCH --time=6:00:00
#SBATCH -D /gpfs/u/home/RLML/RLMLngwt/scratch/STYLIZED_IMAGENET/pisco-stylized-imagenet/mae
#SBATCH --gres=gpu:2
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ngwetl@rpi.edu

source /gpfs/u/home/RLML/RLMLngwt/scratch/miniconda3/etc/profile.d/conda.sh
conda activate invariance_env

srun python ImageNet_MAE_feature_extractor_og.py

